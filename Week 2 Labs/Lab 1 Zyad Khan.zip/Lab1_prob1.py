#Question 1

print('Hello my name is: Zyad Khan') #Displays my name
print('My favorite ice cream is: Cookies and Cream') #Displays my favorite Ice cream flavor
print('My favorite season is: Summer') #Displays my favorite season of the year
